import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Date;
import java.text.SimpleDateFormat;

public class LibrarySystem {

    // Define the Book class
    static class Book {
        String title;
        String author;
        String ISBN;
        String genre;
        boolean isBorrowed;
        Date dueDate;
        String borrowerName;

        public Book(String title, String author, String ISBN, String genre) {
            this.title = title;
            this.author = author;
            this.ISBN = ISBN;
            this.genre = genre;
            this.isBorrowed = false;
            this.dueDate = null;
            this.borrowerName = "";
        }

        public String toString() {
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            String status = isBorrowed ? " (Borrowed by " + borrowerName + " - Due: " +
                    (dueDate != null ? sdf.format(dueDate) : "N/A") + ")" : " (Available)";
            return "Title: " + title + " | Author: " + author + " | ISBN: " + ISBN +
                    " | Genre: " + genre + status;
        }
    }

    // Define the Member class
    static class Member {
        String name;
        String memberId;
        String email;
        ArrayList<Book> borrowedBooks;

        public Member(String name, String memberId, String email) {
            this.name = name;
            this.memberId = memberId;
            this.email = email;
            this.borrowedBooks = new ArrayList<>();
        }

        public String toString() {
            return "Name: " + name + " | ID: " + memberId + " | Email: " + email +
                    " | Books Borrowed: " + borrowedBooks.size();
        }
    }

    // Lists to store books and members
    private static ArrayList<Book> books = new ArrayList<>();
    private static ArrayList<Member> members = new ArrayList<>();

    // Main method
    public static void main(String[] args) {
        // Create sample data
        initializeSampleData();

        // Create the main frame for the application
        JFrame frame = new JFrame("Library Management System");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Create tabbed pane for different functionalities
        JTabbedPane tabbedPane = new JTabbedPane();

        // Create panels for each tab
        JPanel bookManagementPanel = createBookManagementPanel();
        JPanel memberManagementPanel = createMemberManagementPanel();
        JPanel borrowingPanel = createBorrowingPanel();
        JPanel searchPanel = createSearchPanel();
        JPanel reportsPanel = createReportsPanel();

        // Add tabs to the tabbed pane
        tabbedPane.addTab("Book Management", bookManagementPanel);
        tabbedPane.addTab("Member Management", memberManagementPanel);
        tabbedPane.addTab("Borrow/Return", borrowingPanel);
        tabbedPane.addTab("Search", searchPanel);
        tabbedPane.addTab("Reports", reportsPanel);

        // Add tabbed pane to frame
        frame.add(tabbedPane, BorderLayout.CENTER);

        // Show the frame
        frame.setVisible(true);
    }

    // Method to create the book management panel
    private static JPanel createBookManagementPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        // Input panel for book details
        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 5, 5));

        JLabel titleLabel = new JLabel("Book Title:");
        JTextField titleField = new JTextField();
        JLabel authorLabel = new JLabel("Author:");
        JTextField authorField = new JTextField();
        JLabel isbnLabel = new JLabel("ISBN:");
        JTextField isbnField = new JTextField();
        JLabel genreLabel = new JLabel("Genre:");
        JTextField genreField = new JTextField();

        inputPanel.add(titleLabel);
        inputPanel.add(titleField);
        inputPanel.add(authorLabel);
        inputPanel.add(authorField);
        inputPanel.add(isbnLabel);
        inputPanel.add(isbnField);
        inputPanel.add(genreLabel);
        inputPanel.add(genreField);

        // Buttons for book management
        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add Book");
        JButton deleteButton = new JButton("Delete Book");
        JButton clearButton = new JButton("Clear Fields");

        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);

        // Book list display
        DefaultTableModel bookTableModel = new DefaultTableModel(
                new Object[]{"Title", "Author", "ISBN", "Genre", "Status"}, 0
        );
        JTable bookTable = new JTable(bookTableModel);
        JScrollPane scrollPane = new JScrollPane(bookTable);

        // Add action listeners
        addButton.addActionListener(e -> {
            String title = titleField.getText();
            String author = authorField.getText();
            String isbn = isbnField.getText();
            String genre = genreField.getText();

            if (!title.isEmpty() && !author.isEmpty() && !isbn.isEmpty()) {
                // Check if ISBN already exists
                boolean isbnExists = books.stream().anyMatch(book -> book.ISBN.equals(isbn));
                if (isbnExists) {
                    JOptionPane.showMessageDialog(null, "A book with this ISBN already exists.");
                    return;
                }

                books.add(new Book(title, author, isbn, genre));
                updateBookTable(bookTableModel);
                clearBookFields(titleField, authorField, isbnField, genreField);
            } else {
                JOptionPane.showMessageDialog(null, "Please fill in all required fields.");
            }
        });

        deleteButton.addActionListener(e -> {
            int selectedRow = bookTable.getSelectedRow();
            if (selectedRow != -1) {
                String isbn = (String) bookTableModel.getValueAt(selectedRow, 2);
                books.removeIf(book -> book.ISBN.equals(isbn));
                updateBookTable(bookTableModel);
            } else {
                JOptionPane.showMessageDialog(null, "Please select a book to delete.");
            }
        });

        clearButton.addActionListener(e -> {
            clearBookFields(titleField, authorField, isbnField, genreField);
        });

        // Add components to panel
        panel.add(inputPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.CENTER);
        panel.add(scrollPane, BorderLayout.SOUTH);

        // Update the table with existing books
        updateBookTable(bookTableModel);

        return panel;
    }

    // Method to create the member management panel
    private static JPanel createMemberManagementPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        // Input panel for member details
        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 5, 5));

        JLabel nameLabel = new JLabel("Member Name:");
        JTextField nameField = new JTextField();
        JLabel idLabel = new JLabel("Member ID:");
        JTextField idField = new JTextField();
        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField();

        inputPanel.add(nameLabel);
        inputPanel.add(nameField);
        inputPanel.add(idLabel);
        inputPanel.add(idField);
        inputPanel.add(emailLabel);
        inputPanel.add(emailField);

        // Buttons for member management
        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add Member");
        JButton deleteButton = new JButton("Delete Member");
        JButton clearButton = new JButton("Clear Fields");

        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);

        // Member list display
        DefaultTableModel memberTableModel = new DefaultTableModel(
                new Object[]{"Name", "ID", "Email", "Books Borrowed"}, 0
        );
        JTable memberTable = new JTable(memberTableModel);
        JScrollPane scrollPane = new JScrollPane(memberTable);

        // Add action listeners
        addButton.addActionListener(e -> {
            String name = nameField.getText();
            String id = idField.getText();
            String email = emailField.getText();

            if (!name.isEmpty() && !id.isEmpty()) {
                // Check if member ID already exists
                boolean idExists = members.stream().anyMatch(member -> member.memberId.equals(id));
                if (idExists) {
                    JOptionPane.showMessageDialog(null, "A member with this ID already exists.");
                    return;
                }

                members.add(new Member(name, id, email));
                updateMemberTable(memberTableModel);
                nameField.setText("");
                idField.setText("");
                emailField.setText("");
            } else {
                JOptionPane.showMessageDialog(null, "Please fill in all required fields.");
            }
        });

        deleteButton.addActionListener(e -> {
            int selectedRow = memberTable.getSelectedRow();
            if (selectedRow != -1) {
                String id = (String) memberTableModel.getValueAt(selectedRow, 1);
                members.removeIf(member -> member.memberId.equals(id));
                updateMemberTable(memberTableModel);
            } else {
                JOptionPane.showMessageDialog(null, "Please select a member to delete.");
            }
        });

        clearButton.addActionListener(e -> {
            nameField.setText("");
            idField.setText("");
            emailField.setText("");
        });

        // Add components to panel
        panel.add(inputPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.CENTER);
        panel.add(scrollPane, BorderLayout.SOUTH);

        // Update the table with existing members
        updateMemberTable(memberTableModel);

        return panel;
    }

    // Method to create the borrowing panel
    private static JPanel createBorrowingPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        // Input panel for borrowing
        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 5, 5));

        JLabel memberLabel = new JLabel("Member ID:");
        JTextField memberField = new JTextField();
        JLabel bookLabel = new JLabel("Book ISBN:");
        JTextField bookField = new JTextField();
        JLabel daysLabel = new JLabel("Borrow Days:");
        JTextField daysField = new JTextField("14");

        inputPanel.add(memberLabel);
        inputPanel.add(memberField);
        inputPanel.add(bookLabel);
        inputPanel.add(bookField);
        inputPanel.add(daysLabel);
        inputPanel.add(daysField);

        // Buttons for borrowing operations
        JPanel buttonPanel = new JPanel();
        JButton borrowButton = new JButton("Borrow Book");
        JButton returnButton = new JButton("Return Book");
        JButton clearButton = new JButton("Clear Fields");

        buttonPanel.add(borrowButton);
        buttonPanel.add(returnButton);
        buttonPanel.add(clearButton);

        // Borrowed books display
        DefaultTableModel borrowedTableModel = new DefaultTableModel(
                new Object[]{"Title", "Author", "Borrower", "Due Date"}, 0
        );
        JTable borrowedTable = new JTable(borrowedTableModel);
        JScrollPane scrollPane = new JScrollPane(borrowedTable);

        // Add action listeners
        borrowButton.addActionListener(e -> {
            String memberId = memberField.getText();
            String bookIsbn = bookField.getText();
            String daysText = daysField.getText();

            if (!memberId.isEmpty() && !bookIsbn.isEmpty() && !daysText.isEmpty()) {
                try {
                    int days = Integer.parseInt(daysText);
                    borrowBook(memberId, bookIsbn, days);
                    updateBorrowedTable(borrowedTableModel);
                    memberField.setText("");
                    bookField.setText("");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid number of days.");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Please fill in all fields.");
            }
        });

        returnButton.addActionListener(e -> {
            int selectedRow = borrowedTable.getSelectedRow();
            if (selectedRow != -1) {
                String title = (String) borrowedTableModel.getValueAt(selectedRow, 0);
                String borrower = (String) borrowedTableModel.getValueAt(selectedRow, 2);

                returnBook(title, borrower);
                updateBorrowedTable(borrowedTableModel);
            } else {
                JOptionPane.showMessageDialog(null, "Please select a book to return.");
            }
        });

        clearButton.addActionListener(e -> {
            memberField.setText("");
            bookField.setText("");
            daysField.setText("14");
        });

        // Add components to panel
        panel.add(inputPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.CENTER);
        panel.add(scrollPane, BorderLayout.SOUTH);

        // Update the table with borrowed books
        updateBorrowedTable(borrowedTableModel);

        return panel;
    }

    // Method to create the search panel
    private static JPanel createSearchPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        // Search input panel
        JPanel searchInputPanel = new JPanel(new FlowLayout());

        JLabel searchLabel = new JLabel("Search:");
        JTextField searchField = new JTextField(20);
        JComboBox<String> searchType = new JComboBox<>(new String[]{"Title", "Author", "ISBN", "Genre"});
        JButton searchButton = new JButton("Search");

        searchInputPanel.add(searchLabel);
        searchInputPanel.add(searchField);
        searchInputPanel.add(searchType);
        searchInputPanel.add(searchButton);

        // Search results display
        DefaultTableModel searchTableModel = new DefaultTableModel(
                new Object[]{"Title", "Author", "ISBN", "Genre", "Status"}, 0
        );
        JTable searchTable = new JTable(searchTableModel);
        JScrollPane scrollPane = new JScrollPane(searchTable);

        // Add action listener
        searchButton.addActionListener(e -> {
            String query = searchField.getText();
            String type = (String) searchType.getSelectedItem();

            if (!query.isEmpty()) {
                searchBooks(query, type, searchTableModel);
            } else {
                JOptionPane.showMessageDialog(null, "Please enter a search query.");
            }
        });

        // Add components to panel
        panel.add(searchInputPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    // Method to create the reports panel
    private static JPanel createReportsPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        // Report buttons
        JPanel buttonPanel = new JPanel();
        JButton availableBooksButton = new JButton("Available Books");
        JButton borrowedBooksButton = new JButton("Borrowed Books");
        JButton overdueBooksButton = new JButton("Overdue Books");
        JButton memberReportButton = new JButton("Member Report");

        buttonPanel.add(availableBooksButton);
        buttonPanel.add(borrowedBooksButton);
        buttonPanel.add(overdueBooksButton);
        buttonPanel.add(memberReportButton);

        // Report display
        JTextArea reportArea = new JTextArea();
        reportArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(reportArea);

        // Add action listeners
        availableBooksButton.addActionListener(e -> {
            reportArea.setText(generateAvailableBooksReport());
        });

        borrowedBooksButton.addActionListener(e -> {
            reportArea.setText(generateBorrowedBooksReport());
        });

        overdueBooksButton.addActionListener(e -> {
            reportArea.setText(generateOverdueBooksReport());
        });

        memberReportButton.addActionListener(e -> {
            reportArea.setText(generateMemberReport());
        });

        // Add components to panel
        panel.add(buttonPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    // Helper methods for book management
    private static void updateBookTable(DefaultTableModel model) {
        model.setRowCount(0);
        for (Book book : books) {
            String status = book.isBorrowed ? "Borrowed" : "Available";
            model.addRow(new Object[]{book.title, book.author, book.ISBN, book.genre, status});
        }
    }

    private static void clearBookFields(JTextField title, JTextField author, JTextField isbn, JTextField genre) {
        title.setText("");
        author.setText("");
        isbn.setText("");
        genre.setText("");
    }

    // Helper methods for member management
    private static void updateMemberTable(DefaultTableModel model) {
        model.setRowCount(0);
        for (Member member : members) {
            model.addRow(new Object[]{member.name, member.memberId, member.email, member.borrowedBooks.size()});
        }
    }

    // Helper methods for borrowing operations
    private static void borrowBook(String memberId, String bookIsbn, int days) {
        Member member = findMemberById(memberId);
        Book book = findBookByIsbn(bookIsbn);

        if (member == null) {
            JOptionPane.showMessageDialog(null, "Member not found.");
            return;
        }

        if (book == null) {
            JOptionPane.showMessageDialog(null, "Book not found.");
            return;
        }

        if (book.isBorrowed) {
            JOptionPane.showMessageDialog(null, "Book is already borrowed.");
            return;
        }

        // Set book as borrowed
        book.isBorrowed = true;
        book.borrowerName = member.name;

        // Calculate due date
        Date dueDate = new Date(System.currentTimeMillis() + (days * 24L * 60 * 60 * 1000));
        book.dueDate = dueDate;

        // Add book to member's borrowed list
        member.borrowedBooks.add(book);

        JOptionPane.showMessageDialog(null, "Book borrowed successfully. Due date: " +
                new SimpleDateFormat("MM/dd/yyyy").format(dueDate));
    }

    private static void returnBook(String title, String borrower) {
        Book book = findBookByTitleAndBorrower(title, borrower);

        if (book == null) {
            JOptionPane.showMessageDialog(null, "Book not found or not borrowed by this member.");
            return;
        }

        // Find the member
        Member member = findMemberByName(borrower);
        if (member != null) {
            member.borrowedBooks.remove(book);
        }

        // Reset book status
        book.isBorrowed = false;
        book.borrowerName = "";
        book.dueDate = null;

        JOptionPane.showMessageDialog(null, "Book returned successfully.");
    }

    private static void updateBorrowedTable(DefaultTableModel model) {
        model.setRowCount(0);
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

        for (Book book : books) {
            if (book.isBorrowed) {
                model.addRow(new Object[]{
                        book.title,
                        book.author,
                        book.borrowerName,
                        book.dueDate != null ? sdf.format(book.dueDate) : "N/A"
                });
            }
        }
    }

    // Helper methods for search functionality
    private static void searchBooks(String query, String type, DefaultTableModel model) {
        model.setRowCount(0);

        for (Book book : books) {
            boolean match = false;

            switch (type) {
                case "Title":
                    match = book.title.toLowerCase().contains(query.toLowerCase());
                    break;
                case "Author":
                    match = book.author.toLowerCase().contains(query.toLowerCase());
                    break;
                case "ISBN":
                    match = book.ISBN.toLowerCase().contains(query.toLowerCase());
                    break;
                case "Genre":
                    match = book.genre.toLowerCase().contains(query.toLowerCase());
                    break;
            }

            if (match) {
                String status = book.isBorrowed ? "Borrowed" : "Available";
                model.addRow(new Object[]{book.title, book.author, book.ISBN, book.genre, status});
            }
        }
    }

    // Helper methods for report generation
    private static String generateAvailableBooksReport() {
        StringBuilder report = new StringBuilder();
        report.append("AVAILABLE BOOKS REPORT\n");
        report.append("=====================\n\n");

        int count = 0;
        for (Book book : books) {
            if (!book.isBorrowed) {
                report.append(book.toString()).append("\n");
                count++;
            }
        }

        report.append("\nTotal available books: ").append(count);
        return report.toString();
    }

    private static String generateBorrowedBooksReport() {
        StringBuilder report = new StringBuilder();
        report.append("BORROWED BOOKS REPORT\n");
        report.append("=====================\n\n");

        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        int count = 0;
        for (Book book : books) {
            if (book.isBorrowed) {
                report.append("Title: ").append(book.title)
                        .append(" | Author: ").append(book.author)
                        .append(" | Borrower: ").append(book.borrowerName)
                        .append(" | Due Date: ").append(book.dueDate != null ? sdf.format(book.dueDate) : "N/A")
                        .append("\n");
                count++;
            }
        }

        report.append("\nTotal borrowed books: ").append(count);
        return report.toString();
    }

    private static String generateOverdueBooksReport() {
        StringBuilder report = new StringBuilder();
        report.append("OVERDUE BOOKS REPORT\n");
        report.append("====================\n\n");

        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        Date currentDate = new Date();
        int count = 0;

        for (Book book : books) {
            if (book.isBorrowed && book.dueDate != null && book.dueDate.before(currentDate)) {
                report.append("Title: ").append(book.title)
                        .append(" | Author: ").append(book.author)
                        .append(" | Borrower: ").append(book.borrowerName)
                        .append(" | Due Date: ").append(sdf.format(book.dueDate))
                        .append("\n");
                count++;
            }
        }

        report.append("\nTotal overdue books: ").append(count);
        return report.toString();
    }

    private static String generateMemberReport() {
        StringBuilder report = new StringBuilder();
        report.append("MEMBERS REPORT\n");
        report.append("==============\n\n");

        for (Member member : members) {
            report.append(member.toString()).append("\n");

            if (!member.borrowedBooks.isEmpty()) {
                report.append("  Borrowed Books:\n");
                for (Book book : member.borrowedBooks) {
                    report.append("    - ").append(book.title);
                    if (book.dueDate != null) {
                        report.append(" (Due: ").append(new SimpleDateFormat("MM/dd/yyyy").format(book.dueDate)).append(")");
                    }
                    report.append("\n");
                }
            }
            report.append("\n");
        }

        report.append("Total members: ").append(members.size());
        return report.toString();
    }

    // Helper methods to find books and members
    private static Book findBookByIsbn(String isbn) {
        for (Book book : books) {
            if (book.ISBN.equals(isbn)) {
                return book;
            }
        }
        return null;
    }

    private static Book findBookByTitleAndBorrower(String title, String borrower) {
        for (Book book : books) {
            if (book.title.equals(title) && book.borrowerName.equals(borrower)) {
                return book;
            }
        }
        return null;
    }

    private static Member findMemberById(String id) {
        for (Member member : members) {
            if (member.memberId.equals(id)) {
                return member;
            }
        }
        return null;
    }

    private static Member findMemberByName(String name) {
        for (Member member : members) {
            if (member.name.equals(name)) {
                return member;
            }
        }
        return null;
    }

    // Method to initialize sample data
    private static void initializeSampleData() {
        // Add sample books
        books.add(new Book("The Great Gatsby", "F. Scott Fitzgerald", "9780743273565", "Fiction"));
        books.add(new Book("To Kill a Mockingbird", "Harper Lee", "9780061120084", "Fiction"));
        books.add(new Book("1984", "George Orwell", "9780451524935", "Dystopian"));
        books.add(new Book("Pride and Prejudice", "Jane Austen", "9780141439518", "Romance"));
        books.add(new Book("The Hobbit", "J.R.R. Tolkien", "9780547928227", "Fantasy"));

        // Add sample members
        members.add(new Member("John Smith", "M001", "john.smith@email.com"));
        members.add(new Member("Jane Doe", "M002", "jane.doe@email.com"));
        members.add(new Member("Robert Johnson", "M003", "robert.johnson@email.com"));
    }
}